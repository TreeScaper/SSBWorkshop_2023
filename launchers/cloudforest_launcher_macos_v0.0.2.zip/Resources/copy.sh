#!/bin/bash

SCRIPT_DIR=$(dirname "$0")
cd $SCRIPT_DIR
if [ $? -ne 0 ]; then
    echo Error entering directory
    exit 1
fi
if [[ $NO_UNPACK != true ]]; then
    echo "$0 Unpacking cloudforest tarball."
    rm -r cloudforest
    tar -xvzf cloudforest.tar.gz
fi

echo "$0 Copy files into container."
docker cp cloudforest/templates/cloudforest.mako  cloudforest:/galaxy-central/static/plugins/visualizations/cloudforest/templates/
docker cp cloudforest/static/bundle*.js cloudforest:/galaxy-central/static/plugins/visualizations/cloudforest/static
docker cp cloudforest/config/cloudforest.xml cloudforest:/galaxy-central/static/plugins/visualizations/cloudforest/config
docker cp cloudforest/templates/cloudforest.mako  cloudforest:/galaxy-central/config/plugins/visualizations/cloudforest/templates/
docker cp cloudforest/static/bundle*.js cloudforest:/galaxy-central/config/plugins/visualizations/cloudforest/static
docker cp cloudforest/config/cloudforest.xml cloudforest:/galaxy-central/config/plugins/visualizations/cloudforest/config
docker cp cloudforest/config/cloudforest.xml cloudforest:/galaxy-central/config/plugins/visualizations/cloudforest/config

# Why does xml need to be copied to /export but js can go to /galaxy-central?
docker cp treescaper_tool/treescaper-community.xml cloudforest:/galaxy-central/tools/treescaper
docker cp treescaper_tool/treescaper-community.xml cloudforest:/export/galaxy-central/tools/treescaper
docker cp treescaper_tool/treescaper-nldr.xml cloudforest:/galaxy-central/tools/treescaper
docker cp treescaper_tool/treescaper-nldr.xml cloudforest:/export/galaxy-central/tools/treescaper

if [[ $RESTART_GALAXY == true ]]; then
    echo "$0 Restarting Galaxy."
    docker exec -it cloudforest supervisorctl restart galaxy:
fi
