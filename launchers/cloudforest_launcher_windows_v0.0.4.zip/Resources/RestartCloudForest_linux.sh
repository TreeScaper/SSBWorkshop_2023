#!/bin/bash

SCRIPT_DIR=$(dirname "$0")
$SCRIPT_DIR/run.sh --stop && $SCRIPT_DIR/run.sh --tag beta_testing
if [ $? -eq 0 ]; then
	echo "Finished."
else
	echo "Error launching."
fi
sleep 120
