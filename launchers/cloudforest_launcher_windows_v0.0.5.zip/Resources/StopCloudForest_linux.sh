#!/bin/bash

SCRIPT_DIR=$(dirname "$0")
$SCRIPT_DIR/run.sh --stop
if [ $? -eq 0 ]; then
	echo "Finished."
else
	echo "Error launching."
fi
sleep 120
