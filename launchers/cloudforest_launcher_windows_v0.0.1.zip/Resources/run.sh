#!/bin/bash

#
# This script starts and stops the CloudForest instance. It manages user options and
# runs the necessary docker-compose configuration.
#

SCRIPT_DIR=$(dirname "$0")

print_help () {
    cat << EOF
Usage: ./run_it.sh [--tag tag_name] [--sftp] [--follow]

--tag <tag_name>
Run an image from the cloudforestphylo/cloudforestgalaxy:latest
repository with the tag <tag_name>. Use latest for the most recent build from master.

--follow
Output logs after starting the container.

--stop
Bring down the CloudForest service

--usage
--help
Display this message.
EOF
}

# Follow log output after running container.
FOLLOW_LOGS=false

# Optional arguments before the required tag and container name
while [[ $# -gt 0 ]]; do
    case $1 in
	"--tag")
        shift
        export CLOUDFOREST_TAG=$1
        shift
        ;;
    "--follow")
        FOLLOW_LOGS=true
        shift
        ;;
    "--stop")
        STOP_CONTAINER=true
        shift
        ;;
    "--help"|"--usage")
        print_help
        exit 0
        ;;
	*)
	    echo "Error: unrecognized option: $1"
	    exit 1
	    ;;
    esac
done

# Create .env file if it doesn't exist
if [[ ! -f .env ]]; then
    cp "$SCRIPT_DIR/.env.example" .env
fi

COMPOSE_FILE_ARGS=" -f $SCRIPT_DIR/docker-compose.yml"
if [[ ! -z $CLOUDFOREST_TAG ]]; then
    COMPOSE_FILE_ARGS="$COMPOSE_FILE_ARGS -f $SCRIPT_DIR/docker-compose-remote.yml"
    docker-compose $COMPOSE_FILE_ARGS pull cloudforest
else
    echo "Dockerhub tag must be specified with --tag option"
fi

if [[ $STOP_CONTAINER == "true" ]]; then
    docker-compose $COMPOSE_FILE_ARGS down
    exit 0
fi

# Bring up service with docker-compose.
docker-compose $COMPOSE_FILE_ARGS up -d $COMPOSE_BUILD_ARGS

if [[ $FOLLOW_LOGS == "true" ]]; then
    docker logs -f "$CONTAINER_NAME"
fi
