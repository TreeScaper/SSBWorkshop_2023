#!/bin/bash

SCRIPT_DIR=$(dirname "$0")
$SCRIPT_DIR/run.sh --stop
